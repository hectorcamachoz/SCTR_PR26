#include "driver/uart.h"
#include "encoder.h"
#include "usbSerial.h"
#include <stdio.h>
#include <string.h>

extern "C" void app_main(void) {
  // Setup
  UsbSerial serial;
  Encoder encoder(0, 2);

  int count{0};
  while (1) {
    count = encoder.get_count();
    serial.send_int(count);
    vTaskDelay(500);
  }
}
